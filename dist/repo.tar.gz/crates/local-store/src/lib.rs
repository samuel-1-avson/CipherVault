//! # CipherVault Local Storage
//!
//! Provides transactional SQLite storage for vault configuration, device authority,
//! confidential tracked files, local encrypted chunk outbox, and snapshot history.

pub mod db;
pub mod error;
pub mod keyring;

pub use db::{LocalVaultStore, PendingUpload, RecoveryDescriptors};
pub use error::LocalStoreError;
pub use keyring::{protect_secret, unprotect_secret};
